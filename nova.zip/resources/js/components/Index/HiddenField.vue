<template>
  <div class="hidden" />
</template>

<script>
export default {
  props: ['resourceName', 'field'],
}
</script>
